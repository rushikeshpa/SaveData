package com.youtube.jwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportsKtApplicationTests {

    @Test
    void contextLoads() {
    }

}
