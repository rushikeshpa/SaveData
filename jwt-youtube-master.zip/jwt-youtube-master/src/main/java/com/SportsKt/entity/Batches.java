package com.SportsKt.entity;

import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.*;

@Entity
public class Batches {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String batchName;
	private String batchDescription;
	private double batchFees;
	private boolean subscription;
	private java.sql.Timestamp sqlTimestamp;
	
	public Batches() {
		
	}
	
	public Batches(String batchName, String batchDescription, double batchFees, boolean subscription,
			Timestamp sqlTimestamp) {
		super();
		this.batchName = batchName;
		this.batchDescription = batchDescription;
		this.batchFees = batchFees;
		this.subscription = subscription;
		this.sqlTimestamp = sqlTimestamp;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getBatchName() {
		return batchName;
	}

	public void setBatchName(String batchName) {
		this.batchName = batchName;
	}

	public String getBatchDescription() {
		return batchDescription;
	}

	public void setBatchDescription(String batchDescription) {
		this.batchDescription = batchDescription;
	}

	public double getBatchFees() {
		return batchFees;
	}

	public void setBatchFees(double batchFees) {
		this.batchFees = batchFees;
	}

	public boolean isSubscription() {
		return subscription;
	}

	public void setSubscription(boolean subscription) {
		this.subscription = subscription;
	}

	public java.sql.Timestamp getSqlTimestamp() {
		return sqlTimestamp;
	}

	public void setSqlTimestamp(java.sql.Timestamp sqlTimestamp) {
		this.sqlTimestamp = sqlTimestamp;
	}
	
	
	
	
	
	
	
}
