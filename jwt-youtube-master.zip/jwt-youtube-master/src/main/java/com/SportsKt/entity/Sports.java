package com.SportsKt.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity

public class Sports {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String sportsName;
	private String sportsDescription;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "sb_fid", referencedColumnName ="id")
	List<Batches> batches = new ArrayList<>();
	
	
	public Sports() {
		
	}
	
	public Sports(String sportsName, String sportsDescription) {
		super();
		this.sportsName = sportsName;
		this.sportsDescription = sportsDescription;
	}

	
	
	
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getSportsName() {
		return sportsName;
	}

	public void setSportsName(String sportsName) {
		this.sportsName = sportsName;
	}

	public String getSportsDescription() {
		return sportsDescription;
	}

	public void setSportsDescription(String sportsDescription) {
		this.sportsDescription = sportsDescription;
	}

	public List<Batches> getBatches() {
		return batches;
	}

	public void setBatches(List<Batches> batches) {
		this.batches = batches;
	}
	
	
	
	
	

}
