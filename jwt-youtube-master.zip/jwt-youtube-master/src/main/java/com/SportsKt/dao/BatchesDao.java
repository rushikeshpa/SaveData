package com.SportsKt.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.SportsKt.entity.Batches;

@Repository
public interface BatchesDao extends JpaRepository<Batches, Long> {

}
