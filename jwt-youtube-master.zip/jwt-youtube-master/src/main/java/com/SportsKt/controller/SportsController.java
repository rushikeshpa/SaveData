package com.SportsKt.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class SportsController {
    
	//get Sports
	
	//get Sports by id
	
	//create sports
	
	//update sports
	//delete sports by id
	
	
}
