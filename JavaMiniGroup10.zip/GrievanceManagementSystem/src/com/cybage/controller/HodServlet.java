package com.cybage.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cybage.dao.DepartmentDaoImpl;
import com.cybage.dto.ComplaintListDTO;
import com.cybage.model.*;
import com.cybage.model.Department;
import com.cybage.model.User;
import com.cybage.service.HodServiceImpl;
import com.cybage.service.IHodService;
import com.cybage.service.UserService;

/**
 * Servlet implementation class HodServlet
 */
@WebServlet("/HodServlet")
public class HodServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private IHodService hodService;
    
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HodServlet() {
        super();
        hodService=new HodServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Department department=null;
		HttpSession httpSession = request.getSession();
		User user=(User) httpSession.getAttribute("user");
		if(user.getUserRole().name().equals("DEPARTMENT_HEAD")) {
			
		department=hodService.getDepartmentByHodId(user.getUserId());
			
			
			
		}
//		int departmentId=(int)httpSession.getAttribute("departmentId");
		if(department!=null) {
	    List<ComplaintListDTO> listComplaints=hodService.getComplaintByDepartmentId(department.getDepartmentId());
		request.setAttribute("listComplaintsByHodId", listComplaints);
		RequestDispatcher RequestDispatcher=request.getRequestDispatcher("viewDeptComplaint.jsp");
		RequestDispatcher.forward(request, response);
		System.out.println("In controller ListComplaintsByHodId 2");
		}		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		RequestDispatcher RequestDispatcher=request.getRequestDispatcher("transferDept.jsp");
		RequestDispatcher.forward(request, response);

	}

}
