package com.cybage.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Base64;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.jasper.tagplugins.jstl.core.Out;
import org.apache.log4j.Logger;

import com.cybage.model.User;
import com.cybage.service.AdminService;
import com.cybage.service.UserService;
import com.mysql.cj.Session;


@WebServlet("/Authenticate")
public class Authenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserService userService;
	private AdminService adminService;
	User user;
	private static final Logger LOGGER = Logger.getLogger(Authenticate.class.getName());
	
	public Authenticate() {
		super();
		userService = new UserService();
		adminService = new AdminService();
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String loginId = request.getParameter("loginid");
		String password = Base64.getEncoder().encodeToString(request.getParameter("loginpassword").getBytes());

		
			user = userService.auntheticateUser(loginId, password);
			
			HttpSession session = request.getSession(true);
			session.setAttribute("user", user);
			if (user == null) {
				LOGGER.warn("Invalid Credential ");
				request.setAttribute("invalid", "*Invalid Credential");
				request.getRequestDispatcher("login.jsp").forward(request, response);
				
			}
			else if (user.getUserRole().name().equals("ADMIN")) {
				LOGGER.debug("Admin Logged in"+LocalDateTime.now());
				request.setAttribute("count_complaint", adminService.getComplaintCount());
				request.getRequestDispatcher("adminhome.jsp").forward(request, response);
			} else if(user.getUserRole().name().equals("DEPARTMENT_HEAD")) {
				LOGGER.debug("Hod Logged in"+LocalDateTime.now());
				request.getRequestDispatcher("DepartmentDashboard.jsp").forward(request, response);
			}else if(user.getUserRole().name().equals("CITIZEN")) {
				LOGGER.debug("Citizens Logged in"+LocalDateTime.now());
				HttpSession httpSession = request.getSession();
				httpSession.setAttribute("user_id", user.getUserId());
				request.getRequestDispatcher("UserDashboard.jsp").forward(request, response);
			}else {
				out.print("Invalid Credentials");
				response.sendRedirect("login.jsp");
				
			}
		
	}
}
