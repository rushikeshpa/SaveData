package com.cybage.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.Base64;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cybage.model.Role;
import com.cybage.model.User;
import com.cybage.service.UserService;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/registerUser")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(RegisterServlet.class.getName());
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegisterServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		response.setContentType("text/html");
		String user_name = request.getParameter("name");
		String user_loginid = request.getParameter("loginid");
		String user_password = Base64.getEncoder().encodeToString(request.getParameter("loginpassword").getBytes());
		String user_mobileno = (String) request.getParameter("mobilenumber");
		String user_address = request.getParameter("address");
		// String date = new SimpleDateFormat("dd-mm-yyyy").format(new Date());
		long d = System.currentTimeMillis();
		Date date = new Date(d);

		User user = new User(user_name, user_loginid, user_password, user_mobileno, user_address, Role.CITIZEN, date);

		UserService userService = new UserService();

		try {
			boolean value = userService.registerUser(user);
			if (value) {
				LOGGER.info("user register sucessfully");
				response.sendRedirect("login.jsp");
			}else {
				PrintWriter printWriter = response.getWriter();
				printWriter.print("Enter Valid Credentiales");
				response.sendRedirect("register.jsp");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
