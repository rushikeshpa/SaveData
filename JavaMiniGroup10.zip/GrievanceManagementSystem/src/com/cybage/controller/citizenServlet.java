package com.cybage.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cybage.model.ComplaintStatus;
import com.cybage.model.Complaints;
import com.cybage.model.Department;
import com.cybage.service.UserService;

/**
 * Servlet implementation class citizenServlet
 */
@WebServlet("/addComplaint")
public class citizenServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public citizenServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
//    private void listDisplay(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//    	 UserService userService = new UserService();
//    	 
//    	 try {
//    		 
//             List<Department> departmentsList = userService.viewDepartment();
//             request.setAttribute("departmentsList", departmentsList);
//
//             RequestDispatcher dispatcher = request.getRequestDispatcher("addComplaint.jsp");
//             dispatcher.forward(request, response);
//
//         } catch (Exception e) {
//             e.printStackTrace();
//            
//         }
//    	
//    }
    

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserService userService = new UserService();
		HttpSession httpSession = request.getSession();
		
		//int departmentID = Integer.parseInt(request.getParameter("department"));
		
	
	
		
		
		
		
		
	 
		 
         List<Department> departmentsList = userService.viewDepartment();
        httpSession.setAttribute("departmentsLists", departmentsList);
        response.sendRedirect("addComplaint.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession httpSession = request.getSession();
		
		int user_id = (Integer)httpSession.getAttribute("user_id");
		int departmentID = Integer.parseInt(request.getParameter("departmentNo"));
		System.out.println("departmentId = "+departmentID);
//		String department = request.getParameter("departments");
//		String complaint = request.getParameter("complaints");
		String discription = request.getParameter("discription");
		
		long d = System.currentTimeMillis();
		Date date = new Date(d);
		
		String status = ComplaintStatus.PENDING.toString();
		Complaints complaints	 = new Complaints(departmentID, discription, date,status, user_id);
				
		
		
		UserService userService = new UserService();
		request.setAttribute("selectDepartmentId",departmentID );

		response.sendRedirect("UserDashboard.jsp");
		
		
		try {
			boolean value = userService.addComplaint(complaints);
			if (value) {
				PrintWriter printWriter = response.getWriter();
				printWriter.print("department Added Successfully");
			}else {
				PrintWriter printWriter = response.getWriter();
				printWriter.print("Department Did Not Add");
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
