package com.cybage.controller;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Base64;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.cybage.model.Department;
import com.cybage.model.Role;
import com.cybage.model.User;
import com.cybage.service.AdminService;
import com.cybage.service.DepartmentService;
import com.cybage.service.UserService;

@WebServlet("/admin")
public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AdminService adminService;
	private DepartmentService departmentService;
	private UserService userService;
	private static final Logger LOGGER = Logger.getLogger(AdminController.class.getName());
	public AdminController() {
		super();
		adminService = new AdminService();
		departmentService = new DepartmentService();
		userService = new UserService();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		switch (request.getParameter("action")) {
		case "listHOD":

			request.setAttribute("hod_list", adminService.getAllHod());
			request.setAttribute("count_complaint", adminService.getComplaintCount());
			request.getRequestDispatcher("hod.jsp").forward(request, response);
			break;

		case "listDepartment":
			request.setAttribute("department_list", departmentService.getAllDepartment());
			request.setAttribute("count_complaint", adminService.getComplaintCount());
			request.getRequestDispatcher("department.jsp").forward(request, response);
			break;
			
		case "editHod":
			request.setAttribute("count_complaint", adminService.getComplaintCount());
			request.setAttribute("hod", adminService.getHodById(Integer.parseInt(request.getParameter("id"))));
			request.getRequestDispatcher("edithod.jsp").forward(request, response);
			break;
		case "removeHod":
			request.setAttribute("hod_list", adminService.getAllHod());
			request.setAttribute("hod", adminService.removeHodById(Integer.parseInt(request.getParameter("id"))));
			request.setAttribute("count_complaint", adminService.getComplaintCount());
			request.getRequestDispatcher("adminhome.jsp").forward(request, response);
			break;
		case "editDepartment":

			request.setAttribute("department", departmentService.getDepartmentById(Integer.parseInt(request.getParameter("id"))));
			request.getRequestDispatcher("editdepartment.jsp").forward(request, response);
			break;
		case "removeDepartment":
			request.setAttribute("department_list", departmentService.getAllDepartment());
			request.setAttribute("department", departmentService.removeDepartmentById(Integer.parseInt(request.getParameter("id"))));
			request.setAttribute("count_complaint", adminService.getComplaintCount());
			request.getRequestDispatcher("adminhome.jsp").forward(request, response);
			break;
			
		case "listComplaint":
			request.setAttribute("complaint_list", adminService.getAllComplaint());
			request.getRequestDispatcher("userlog.jsp").forward(request, response);
			break;	
		case "countComplaint":
			request.setAttribute("count_complaint", adminService.getComplaintCount());
			request.getRequestDispatcher("adminhome.jsp").forward(request, response);
			break;
		case "checkUser":
			boolean stat = false;
			String uname = request.getParameter("username");
			
			List<User> userList = userService.getAllUser();
			
			for (User u : userList) {
				if (u.getUserLoginId().equals(uname)) {
					System.out.println("Match found: " + u.getUserLoginId());
					stat = true;
				}
			}

			if (stat) {
				response.setContentType("text/plain");
				response.getWriter().write("exists");
			}
			break;
		case "checkDepartment":
			boolean stat1 = false;
			String department_name = request.getParameter("departmentname");
			
			List<Department> departmentList = departmentService.getAllDepartment();
			
			for (Department d : departmentList) {
				if (d.getDepartmentName().equals(department_name)) {
					System.out.println("Match found: " + d.getDepartmentName());
					stat1 = true;
				}
			}

			if (stat1) {
				response.setContentType("text/plain");
				response.getWriter().write("exists");
			}
			break;
		default:
			break;
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String userName = null;
		switch (request.getParameter("action")) {
//		Base64.getEncoder().encodeToString(request.getParameter("passwordHod").getBytes())
		case "addHOD":
			User user = new User(request.getParameter("ahodName"), request.getParameter("loginIdHod"),
					Base64.getEncoder().encodeToString(request.getParameter("passwordHod").getBytes()), request.getParameter("mobileHod"), Role.DEPARTMENT_HEAD,
					Date.valueOf(LocalDate.now()));
			LOGGER.debug("Hod Added successful");
			adminService.addHod(user);
			userName = user.getUserName();
			request.setAttribute("count_complaint", adminService.getComplaintCount());
			request.getRequestDispatcher("adminhome.jsp").forward(request, response);
			
			break;
		case "addDepartment":
			User user2 = adminService.getUserByName(request.getParameter("hodName"));
			
			
			Department department = new Department(user2, request.getParameter("departmentName"),
					Date.valueOf(LocalDate.now()));
			
			departmentService.addDepartment(department);
			request.setAttribute("count_complaint", adminService.getComplaintCount());
			request.getRequestDispatcher("adminhome.jsp").forward(request, response);
			break;
		case "editHOD":
			User user3 = adminService.getHodById(Integer.parseInt(request.getParameter("id")));
			user3.setUserName(request.getParameter("ahodName"));
			user3.setUserLoginId(request.getParameter("loginIdHod"));
			user3.setUserPassword(request.getParameter("passwordHod"));
			user3.setUserMobileNumber(request.getParameter("mobileHod"));
			user3.setDepartmentName(request.getParameter("newDepartmentName"));
			adminService.editHod(user3);
			request.setAttribute("count_complaint", adminService.getComplaintCount());
			request.getRequestDispatcher("adminhome.jsp").forward(request, response);
			break;
		case "editDepartment":
			Department department2 = departmentService.getDepartmentById(Integer.parseInt(request.getParameter("id")));
			department2.setDepartmentName(request.getParameter("departmentName"));
			department2.setUser(userService.getUserByName(request.getParameter("hodName")));
			departmentService.editDepartment(department2);
			request.setAttribute("count_complaint", adminService.getComplaintCount());
			request.getRequestDispatcher("adminhome.jsp").forward(request, response);
			break;
		default:
			break;
		}

	}

}
