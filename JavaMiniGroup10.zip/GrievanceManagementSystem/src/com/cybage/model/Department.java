package com.cybage.model;

import java.sql.Date;

public class Department {
	private User user;
	
	private int departmentId;
	private String departmentName;
	private Date timestamp;
	
	
	public Department(User user, String departmentName, Date timestamp) {
		super();
		this.user = user;
		this.departmentName = departmentName;
		this.timestamp = timestamp;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public int getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public Department(int departmentId,String departmentName,User user,Date timestamp) {
		super();
		this.user = user;
		this.departmentId = departmentId;
		this.departmentName = departmentName;
		this.timestamp = timestamp;
	}
	
}
