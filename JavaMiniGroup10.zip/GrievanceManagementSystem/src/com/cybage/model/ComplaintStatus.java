package com.cybage.model;

public enum ComplaintStatus {
	COMPLETED,PENDING
}
