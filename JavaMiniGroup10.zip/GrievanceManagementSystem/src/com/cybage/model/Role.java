package com.cybage.model;

public enum Role {

	ADMIN, DEPARTMENT_HEAD, CITIZEN

}
