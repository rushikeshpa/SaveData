package com.cybage.model;

import java.sql.Date;

public class Complaints {
	
	private int complaint_id;
	private int department_id;
	private String complaint_description;
	private Date complaint_timestamp;
	private String complaint_status;
	private Date complaint_resolved;
	private int user_id;
	
	public Complaints() {
		// TODO Auto-generated constructor stub
	}
	public Complaints(int complaint_id, int department_id, String complaint_description, Date complaint_timestamp,
			String complaint_status, Date complaint_resolved, int user_id) {
		super();
		this.complaint_id = complaint_id;
		this.department_id = department_id;
		this.complaint_description = complaint_description;
		this.complaint_timestamp = complaint_timestamp;
		this.complaint_status = complaint_status;
		this.complaint_resolved = complaint_resolved;
		this.user_id = user_id;
	}
	
	public Complaints( int department_id, String complaint_description, Date complaint_timestamp,
			String complaint_status,  int user_id) {
		super();
		this.complaint_id = complaint_id;
		this.department_id = department_id;
		this.complaint_description = complaint_description;
		this.complaint_timestamp = complaint_timestamp;
		this.complaint_status = complaint_status;
		this.complaint_resolved = complaint_resolved;
		this.user_id = user_id;
		System.out.println("modelComplaint");
	}
	
	public int getComplaint_id() {
		return complaint_id;
	}
	public void setComplaint_id(int complaint_id) {
		this.complaint_id = complaint_id;
	}
	public int getDepartment_id() {
		return department_id;
	}
	public void setDepartment_id(int department_id) {
		this.department_id = department_id;
	}
	public String getComplaint_description() {
		return complaint_description;
	}
	public void setComplaint_description(String complaint_description) {
		this.complaint_description = complaint_description;
	}
	public Date getComplaint_timestamp() {
		return complaint_timestamp;
	}
	public void setComplaint_timestamp(Date complaint_timestamp) {
		this.complaint_timestamp = complaint_timestamp;
	}
	public String getComplaint_status() {
		return complaint_status;
	}
	public void setComplaint_status(String coplaint_status) {
		this.complaint_status = coplaint_status;
	}
	public Date getComplaint_resolved() {
		return complaint_resolved;
	}
	public void setComplaint_resolved(Date complaint_resolved) {
		this.complaint_resolved = complaint_resolved;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	@Override
	public String toString() {
		return "Complaints [complaint_id=" + complaint_id + ", department_id=" + department_id
				+ ", complaint_description=" + complaint_description + ", complaint_timestamp=" + complaint_timestamp
				+ ", complaint_status=" + complaint_status + ", complaint_resolved=" + complaint_resolved + ", user_id="
				+ user_id + "]";
	}
	
	
	
}