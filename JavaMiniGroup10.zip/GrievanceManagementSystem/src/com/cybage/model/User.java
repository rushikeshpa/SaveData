package com.cybage.model;

import java.sql.Date;

public class User {
	private int userId;
	private String userName;
	private String userLoginId;
	private String userPassword;
	private String userMobileNumber;
	private String userAddress;
	private Role userRole;
	private Date userRegisterDate;
	private String departmentName;
	
	public User() {
		
	}
	//for getting hod
	public User(int userId, String userName, String userLoginId, String userPassword, String userMobileNumber,
			String userAddress, Role userRole, Date userRegisterDate,String departmentName) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userLoginId = userLoginId;
		this.userPassword = userPassword;
		this.userMobileNumber = userMobileNumber;
		this.userAddress = userAddress;
		this.userRole = userRole;
		this.departmentName = departmentName;
		this.userRegisterDate = userRegisterDate;
		
	}

	


	//for getting user
	public User(int userId, String userName, String userLoginId, String userPassword, String userMobileNumber,
			String userAddress, Role userRole, Date userRegisterDate) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userLoginId = userLoginId;
		this.userPassword = userPassword;
		this.userMobileNumber = userMobileNumber;
		this.userAddress = userAddress;
		this.userRole = userRole;
		this.userRegisterDate = userRegisterDate;
	}
	//for register user
	public User(String userName, String userLoginId, String userPassword, String userMobileNumber, String userAddress,
			Role userRole, Date userRegisterDate) {
		super();
		this.userName = userName;
		this.userLoginId = userLoginId;
		this.userPassword = userPassword;
		this.userMobileNumber = userMobileNumber;
		this.userAddress = userAddress;
		this.userRole = userRole;
		this.userRegisterDate = userRegisterDate;
	}
	//for register Hod
	public User(String userName, String userLoginId, String userPassword, String userMobileNumber,
			Role userRole, Date userRegisterDate) {
		super();
		this.userName = userName;
		this.userLoginId = userLoginId;
		this.userPassword = userPassword;
		this.userMobileNumber = userMobileNumber;
		
		this.userRole = userRole;
		this.userRegisterDate = userRegisterDate;
		
	}
	
	public int getUserId() {
		return userId;
	}
	
	
	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserLoginId() {
		return userLoginId;
	}

	public void setUserLoginId(String userLoginId) {
		this.userLoginId = userLoginId;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getUserMobileNumber() {
		return userMobileNumber;
	}

	public void setUserMobileNumber(String userMobileNumber) {
		this.userMobileNumber = userMobileNumber;
	}

	public String getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}

	public Role getUserRole() {
		return userRole;
	}

	public void setUserRole(Role userRole) {
		this.userRole = userRole;
	}

	public Date getUserRegisterDate() {
		return userRegisterDate;
	}

	public void setUserRegisterDate(Date userRegisterDate) {
		this.userRegisterDate = userRegisterDate;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", userLoginId=" + userLoginId
				+ ", userMobileNumber=" + userMobileNumber + ", userAddress=" + userAddress + ", userRole=" + userRole
				+ ", userRegisterDate=" + userRegisterDate + ", departmentName=" + departmentName + "]";
	}


	
	
}
