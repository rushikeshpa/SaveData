package com.cybage.dto;

public class ComplaintListDTO {
	private String userName;
	private String complaintDescription;
	private String userAddress;
	private String complaintStatus;
	public ComplaintListDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public ComplaintListDTO(String userName, String complaintDescription, String userAddress, String complaintStatus) {
		super();
		this.userName = userName;
		this.complaintDescription = complaintDescription;
		this.userAddress = userAddress;
		this.complaintStatus = complaintStatus;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getComplaintDescription() {
		return complaintDescription;
	}

	public void setComplaintDescription(String complaintDescription) {
		this.complaintDescription = complaintDescription;
	}

	public String getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}

	public String getComplaintStatus() {
		return complaintStatus;
	}

	public void setComplaintStatus(String complaintStatus) {
		this.complaintStatus = complaintStatus;
	}

	@Override
	public String toString() {
		return "ComplaintListDTO [userName=" + userName + ", complaintDescription=" + complaintDescription
				+ ", userAddress=" + userAddress + ", complaintStatus=" + complaintStatus + "]";
	}
	
	
	

}
