package com.cybage.dto;

import java.sql.Date;

public class ComplaintLogDTO {
//	u.user_name,u.user_mobileno,u.user_address,d.department_name,
//	c.complaint_description,c.complaint_register,c.complaint_status,c.complaint_resolved
private String userName;
private String mobileNumber;
private String userAddress;
private String departmentName;
private String complaintDescription;
private Date complaintRegister;
private String complaintStatus;
private String complaintResolved;

	public ComplaintLogDTO() {

	}

	public ComplaintLogDTO(String userName, String mobileNumber, String userAddress, String departmentName,
			String complaintDescription, Date complaintRegister, String complaintStatus, String complaintResolved) {
		super();
		this.userName = userName;
		this.mobileNumber = mobileNumber;
		this.userAddress = userAddress;
		this.departmentName = departmentName;
		this.complaintDescription = complaintDescription;
		this.complaintRegister = complaintRegister;
		this.complaintStatus = complaintStatus;
		this.complaintResolved = complaintResolved;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getComplaintDescription() {
		return complaintDescription;
	}

	public void setComplaintDescription(String complaintDescription) {
		this.complaintDescription = complaintDescription;
	}

	public Date getComplaintRegister() {
		return complaintRegister;
	}

	public void setComplaintRegister(Date complaintRegister) {
		this.complaintRegister = complaintRegister;
	}

	public String getComplaintStatus() {
		return complaintStatus;
	}

	public void setComplaintStatus(String complaintStatus) {
		this.complaintStatus = complaintStatus;
	}

	public String getComplaintResolved() {
		return complaintResolved;
	}

	public void setComplaintResolved(String complaintResolved) {
		this.complaintResolved = complaintResolved;
	}

	@Override
	public String toString() {
		return "ComplaintLogDTO [userName=" + userName + ", mobileNumber=" + mobileNumber + ", userAddress="
				+ userAddress + ", departmentName=" + departmentName + ", complaintDescription=" + complaintDescription
				+ ", complaintRegister=" + complaintRegister + ", complaintStatus=" + complaintStatus
				+ ", complaintResolved=" + complaintResolved + "]";
	}
	

}
