package com.cybage.service;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cybage.dao.DepartmentDaoImpl;
import com.cybage.model.Department;

public class DepartmentService {
	private DepartmentDaoImpl departmentDaoImpl;
	
	public DepartmentService() {
	departmentDaoImpl = new DepartmentDaoImpl();
	}
	
	public boolean addDepartment(Department department) {
	return departmentDaoImpl.addDepartment(department);
	}

	public boolean removeDepartmentById(int departmentId) {
		return departmentDaoImpl.removeDepartmentById(departmentId);
	}

	
	public Department getDepartmentByHodId(int headOfHeadId) {
		return departmentDaoImpl.getDepartmentByHodId(headOfHeadId);
	}

	
	public Department getDepartmentById(int departmentId) {
	return departmentDaoImpl.getDepartmentById(departmentId);
	}

	
	public boolean editDepartment(Department department) {
	return departmentDaoImpl.editDepartment(department);
	}

	
	public List<Department> getAllDepartment() {
		
	return departmentDaoImpl.getAllDepartment();
	}
}

