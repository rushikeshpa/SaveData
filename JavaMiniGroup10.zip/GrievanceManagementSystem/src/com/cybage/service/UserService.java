package com.cybage.service;

import java.util.List;

import com.cybage.dao.DepartmentDaoImpl;
import com.cybage.dao.UserDaoImpl;
import com.cybage.model.Complaints;
import com.cybage.model.Department;
import com.cybage.model.User;

public class UserService {
	private UserDaoImpl userDaoImpl;
	private DepartmentDaoImpl departmentDaoImpl;

	public UserService() {
		userDaoImpl = new UserDaoImpl();
		departmentDaoImpl = new DepartmentDaoImpl();
	}

	public User auntheticateUser(String userLoginId, String userPassword) {
		return userDaoImpl.auntheticateUser(userLoginId, userPassword);
	}

	public boolean registerUser(User user) {
		return userDaoImpl.registerUser(user);
	}

	public boolean editUser(User user) {
		return userDaoImpl.editUser(user);
	}

	public boolean removeUserById(int userId) {
		return userDaoImpl.removeUserById(userId);
	}

	public User getUserById(int userId) {
		return userDaoImpl.getUserById(userId);
	}

	public User getUserByName(String userName) {
		return userDaoImpl.getUserByName(userName);
	}

	public List<User> getAllUser() {
		return userDaoImpl.getAllUser();

	}
	public boolean addComplaint(Complaints complaints) {
		return userDaoImpl.addComplaint(complaints);
	}

	public List<Complaints> viewComplaint(int id) {
		System.out.println("service Layer");
		return userDaoImpl.getAllComplaint(id);
		
	}
	public List<Department> viewDepartment() {
		
		return departmentDaoImpl.getAllDepartment();
	}

}
