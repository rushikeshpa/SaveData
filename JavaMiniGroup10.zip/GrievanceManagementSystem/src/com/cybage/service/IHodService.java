package com.cybage.service;

import java.util.List;

import com.cybage.dto.ComplaintListDTO;
import com.cybage.model.Department;

public interface IHodService {

	List<ComplaintListDTO> getComplaintByDepartmentId(int departmentId);
	Department getDepartmentByHodId(int headOfHeadId);
}
