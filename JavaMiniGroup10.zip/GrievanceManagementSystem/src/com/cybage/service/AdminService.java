package com.cybage.service;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cybage.dao.AdminDaoImpl;
import com.cybage.dto.ComplaintLogDTO;
import com.cybage.model.Role;
import com.cybage.model.User;

public class AdminService {
	private AdminDaoImpl adminDaoImpl;
	private UserService userService;

	public AdminService() {
		adminDaoImpl = new AdminDaoImpl();
		userService = new UserService();	}

	public boolean addHod(User user) {
		return adminDaoImpl.addHod(user);
	}

	public boolean removeHodById(int userId) {
		return adminDaoImpl.removeHodById(userId);
	}

	public User getHodByDepartmentId(int departentId) {
		return adminDaoImpl.getHodByDepartmentId(departentId);
	}

	public User getHodById(int userId) {
		return adminDaoImpl.getHodById(userId);
	}

	public boolean editHod(User user) {
		return adminDaoImpl.editHod(user);
	}
	public User getUserByName(String userName) {
		return	userService.getUserByName(userName);
	}
	public List<User> getAllHod() {
		return adminDaoImpl.getAllHod();
	}
	public List<ComplaintLogDTO> getAllComplaint() {
			return adminDaoImpl.getAllComplaint();
	}
	public Integer[] getComplaintCount() {
		return adminDaoImpl.getComplaintCount();
	}

}
