package com.cybage.service;

import java.util.List;

import com.cybage.dao.DepartmentDaoImpl;
import com.cybage.dao.HodDAO;
import com.cybage.dao.IDepartmentDao;
import com.cybage.dao.IHodDAO;
import com.cybage.dto.ComplaintListDTO;
import com.cybage.model.Department;

public class HodServiceImpl implements IHodService {
private IHodDAO hodDAO;
private IDepartmentDao deptDAO;

	public HodServiceImpl() {
	super();
	hodDAO=new HodDAO() ;
	deptDAO=new DepartmentDaoImpl();
}
 
	
	@Override
	public List<ComplaintListDTO> getComplaintByDepartmentId(int departmentId) {
		// TODO Auto-generated method stub
		return hodDAO.getComplaintByDepartmentId(departmentId);
	}


	@Override
	public Department getDepartmentByHodId(int headOfHeadId) {
		// TODO Auto-generated method stub
	
		return deptDAO.getDepartmentByHodId(headOfHeadId);
	}
	

}
