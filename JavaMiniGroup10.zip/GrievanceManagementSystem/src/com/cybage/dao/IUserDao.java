package com.cybage.dao;

import java.util.List;

import com.cybage.model.Complaints;
import com.cybage.model.User;

public interface IUserDao {
	User auntheticateUser(String userLoginId, String userPassword);

	boolean registerUser(User user);

	boolean editUser(User user);

	boolean removeUserById(int userId);

	User getUserById(int userId);

	User getUserByName(String userName);

	List<User> getAllUser();
	
	boolean addComplaint(Complaints complaints);
	List<Complaints> getAllComplaint(int abc);
}
