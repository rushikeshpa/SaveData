package com.cybage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.sql.Types;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import java.sql.Date;

import com.cybage.model.Complaints;
import com.cybage.model.Role;
import com.cybage.model.User;
import com.cybage.utility.ConnectionUtility;
import com.mysql.cj.conf.ConnectionUrl.Type;

public class UserDaoImpl implements IUserDao {
	Connection connection = ConnectionUtility.getConnection();
	private static final Logger LOGGER = Logger.getLogger(UserDaoImpl.class.getName());
	public User auntheticateUser(String userLoginId, String userPassword) {
		User user = null;

		String sql = "SELECT * FROM user where user_loginid = ? and user_password = ? ";

		try {
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, userLoginId);
			preparedStatement.setString(2, userPassword);
			ResultSet resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {

				user = new User(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3),
						resultSet.getString(4), resultSet.getString(5), resultSet.getString(6),
						Role.valueOf(resultSet.getString(7)), Date.valueOf(resultSet.getString(8).substring(0, 10)),
						resultSet.getString(9));

			}

			
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}//finally{
		//}

		return user;

	}

	public boolean registerUser(User user) {

		try (PreparedStatement preparedStatement = connection.prepareStatement("insert into user values(default,?,?,?,?,?,?,?,?)");) {

			preparedStatement.setString(1, user.getUserName());
			preparedStatement.setString(2, user.getUserLoginId());
			preparedStatement.setString(3, user.getUserPassword());
			preparedStatement.setString(4, user.getUserMobileNumber());
			preparedStatement.setString(5, user.getUserAddress());
			preparedStatement.setString(6, user.getUserRole().name());
			preparedStatement.setDate(7, Date.valueOf(LocalDate.now()));
			preparedStatement.setNull(8, Types.NULL);

			preparedStatement.executeUpdate();
			
		} catch (SQLException e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return true;
	}

	@Override
	public boolean editUser(User user) {
		try (PreparedStatement preparedStatement = connection.prepareStatement(
				"update user set user_name= ? ,user_loginid = ?,user_password = ?, user_mobileno = ?,user_address=?,department_name = ? where user_id=?;");) {

			preparedStatement.setString(1, user.getUserName());
			preparedStatement.setString(2, user.getUserLoginId());
			preparedStatement.setString(3, user.getUserPassword());
			preparedStatement.setString(4, user.getUserMobileNumber());
			preparedStatement.setString(5, user.getUserAddress());
			preparedStatement.setString(6, user.getDepartmentName());
			preparedStatement.setInt(7, user.getUserId());
			preparedStatement.executeUpdate();
			return true;
		} catch (SQLException e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public boolean removeUserById(int userId) {
		try (PreparedStatement preparedStatement = connection.prepareStatement("delete from user where user_Id = ?");) {
			preparedStatement.setInt(1, userId);
			preparedStatement.executeUpdate();
			System.out.println("User " + userId + " deleted successfully");
			return true;
		} catch (SQLException e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public User getUserById(int userId) {
		User user = null;
		try (PreparedStatement preparedStatement = connection
				.prepareStatement("select * from user where user_id = ?");) {
			preparedStatement.setInt(1, userId);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {

				user = new User(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3),
						resultSet.getString(4), resultSet.getString(5), resultSet.getString(6),
						Role.valueOf(resultSet.getString(7)), Date.valueOf(resultSet.getString(8).substring(0, 10)),
						resultSet.getString(9));

			}

		} catch (SQLException e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return user;
	}

	@Override
	public User getUserByName(String userName) {
		User user = null;
		try (PreparedStatement preparedStatement = connection
				.prepareStatement("select * from user where user_name = ?");) {
			preparedStatement.setString(1, userName);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {

				user = new User(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3),
						resultSet.getString(4), resultSet.getString(5), resultSet.getString(6),
						Role.valueOf(resultSet.getString(7)), Date.valueOf(resultSet.getString(8).substring(0, 10)),
						resultSet.getString(9));

			}

		} catch (SQLException e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return user;
	}

	@Override
	public List<User> getAllUser() {
		List<User> userList = new ArrayList<>();
		try {
			try (PreparedStatement preparedStatement = connection.prepareStatement("select * from user");
					ResultSet resultSet = preparedStatement.executeQuery();) {
				
				while (resultSet.next()) {
					userList.add(new User(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3),
							resultSet.getString(4), resultSet.getString(5), resultSet.getString(6),
							Role.valueOf(resultSet.getString(7)), Date.valueOf(resultSet.getString(8).substring(0, 10)),
							resultSet.getString(9)));
				}
				

			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return userList;

	}
	@Override
	public boolean addComplaint(Complaints complaints) {
		try (PreparedStatement preparedStatement = connection.prepareStatement("insert into complaint(department_id,complaint_description,complaint_timestamp,complaint_status,user_id) values(?,?,?,?,?)");) {

			preparedStatement.setInt(1, 	complaints.getDepartment_id());
			preparedStatement.setString(2, complaints.getComplaint_description());
			preparedStatement.setDate(3, complaints.getComplaint_timestamp());
			preparedStatement.setString(4, complaints.getComplaint_status());
			preparedStatement.setInt(5, complaints.getUser_id());

			preparedStatement.executeUpdate();
			
		} catch (SQLException e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return true;
	}
	@Override
	public List<Complaints> getAllComplaint(int abc) {
		List<Complaints> complaintList = new ArrayList<>();
		
		try (PreparedStatement preparedStatement = connection.prepareStatement("select * from complaint where user_id=?");
				) {
			preparedStatement.setInt(1, abc);
			ResultSet resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				do {
					Complaints complaints = new Complaints();
					complaints.setComplaint_id(resultSet.getInt("complaint_id"));
					complaints.setDepartment_id(resultSet.getInt("department_id"));
					complaints.setComplaint_description(resultSet.getString("complaint_description"));
					complaints.setComplaint_timestamp(resultSet.getDate("complaint_timestamp"));
					complaints.setComplaint_status(resultSet.getString("complaint_status"));
					complaints.setComplaint_resolved(resultSet.getDate("complaint_resolved"));
					complaints.setUser_id(resultSet.getInt("user_id"));
					
					complaintList.add(complaints);
					
					
				} while (resultSet.next());
				
			}else {
				return null;
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		
		return complaintList;
	}

}
