package com.cybage.dao;

import java.util.List;

import com.cybage.model.Department;
import com.cybage.model.User;

public interface IDepartmentDao {
boolean addDepartment(Department department);
boolean removeDepartmentById(int departmentId);
Department getDepartmentByHodId(int headOfHeadId);
Department getDepartmentById(int departmentId);
boolean editDepartment(Department department);
List<Department> getAllDepartment();
}
