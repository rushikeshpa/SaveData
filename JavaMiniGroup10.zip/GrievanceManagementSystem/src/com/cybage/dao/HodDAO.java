package com.cybage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cybage.dto.ComplaintListDTO;
import com.cybage.utility.ConnectionUtility;

public class HodDAO implements IHodDAO{

	@Override
	public List<ComplaintListDTO> getComplaintByDepartmentId(int departmentId) {
	
		System.out.println("in DAO ListComplaintsByHodId 1");
		List<ComplaintListDTO> list=new ArrayList<>();
		try (Connection connection=ConnectionUtility.getConnection();
				PreparedStatement preparedStatement1=connection.prepareStatement("Select u.user_name,c.complaint_description,u.user_address,c.complaint_status,d.department_name FROM complaint c INNER JOIN  user u on c.user_id=u.user_id INNER JOIN department d on c.department_id=d.department_id WHERE d.department_id=?");)

		{	
			
			preparedStatement1.setInt(1,departmentId);
			
			ResultSet resultset1 = preparedStatement1.executeQuery();
			while(resultset1.next()) {
				
				list.add(new ComplaintListDTO(resultset1.getString(1), resultset1.getString(2), resultset1.getString(3), resultset1.getString(4)));
			     }	
		
	
		} catch (Exception e) {
			
			e.printStackTrace();
		}

		return list;
	}

}
