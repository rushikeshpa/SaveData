package com.cybage.dao;

import java.util.List;

import com.cybage.dto.ComplaintLogDTO;
import com.cybage.model.Complaints;
import com.cybage.model.Department;
import com.cybage.model.User;

public interface IAdminDao {
		
	boolean addHod(User user);
	boolean removeHodById(int userId);
	User getHodByDepartmentId(int departentId);
	User getHodById(int userId);
	boolean editHod(User user);
	public List<User> getAllHod();
	public List<ComplaintLogDTO> getAllComplaint();
	public Integer[] getComplaintCount(); 
}
