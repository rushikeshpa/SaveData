package com.cybage.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cybage.controller.LogoutController;
import com.cybage.dto.ComplaintLogDTO;
import com.cybage.model.Complaints;
import com.cybage.model.Department;
import com.cybage.model.Role;
import com.cybage.model.User;
import com.cybage.utility.ConnectionUtility;

public class AdminDaoImpl implements IAdminDao {
	Connection connection = ConnectionUtility.getConnection();
	private IUserDao userDao;
	private static final Logger LOGGER = Logger.getLogger(AdminDaoImpl.class.getName());

	public AdminDaoImpl() {
		userDao = new UserDaoImpl();
	}

	@Override
	public boolean addHod(User user) {
		user.setUserRole(Role.DEPARTMENT_HEAD);
		return userDao.registerUser(user);

	}

	@Override
	public boolean removeHodById(int userId) {
		return userDao.removeUserById(userId);
	}

	@Override
	public User getHodByDepartmentId(int departentId) {
		User user = null;
		try (PreparedStatement preparedStatement = connection
				.prepareStatement("select hod_id from department where department_id = ?");) {
			preparedStatement.setInt(1, departentId);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				user = getHodById(resultSet.getInt(1));

			}

		} catch (SQLException e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return user;
	}

	@Override
	public User getHodById(int userId) {
		User user = null;
		try (PreparedStatement preparedStatement = connection
				.prepareStatement("select * from user where user_id = ?");) {
			preparedStatement.setInt(1, userId);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {

				user = new User(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3),
						resultSet.getString(4), resultSet.getString(5), resultSet.getString(6),
						Role.valueOf(resultSet.getString(7)), Date.valueOf(resultSet.getString(8).substring(0, 10)),
						resultSet.getString(9));

			}

		} catch (SQLException e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return user;
	}

	@Override
	public boolean editHod(User user) {
		return userDao.editUser(user);
	}

	@Override
	public List<User> getAllHod() {
		List<User> hodList = new ArrayList<>();
		try {
			try (PreparedStatement preparedStatement = connection
					.prepareStatement("select * from user where user_role='DEPARTMENT_HEAD'");
					ResultSet resultSet = preparedStatement.executeQuery();) {

				while (resultSet.next()) {
					hodList.add(new User(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3),
							resultSet.getString(4), resultSet.getString(5), resultSet.getString(6),
							Role.valueOf(resultSet.getString(7)), Date.valueOf(resultSet.getString(8).substring(0, 10)),
							resultSet.getString(9)));
				}

			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return hodList;

	}

	@Override
	public List<ComplaintLogDTO> getAllComplaint() {
		List<ComplaintLogDTO> complaintLogDTO = new ArrayList<>();
		try {
			try (PreparedStatement preparedStatement = connection
					.prepareStatement("select u.user_name,u.user_mobileno,u.user_address,d.department_name,\r\n"
							+ "c.complaint_description,c.complaint_timestamp,c.complaint_status,c.complaint_resolved\r\n"
							+ "from complaint c inner join user u on c.user_id=u.user_id\r\n"
							+ "inner join department d on c.department_id = d.department_id; ");
					ResultSet resultSet = preparedStatement.executeQuery();) {

				while (resultSet.next()) {
					if(resultSet.getString(8)!=null) {
						complaintLogDTO.add(new ComplaintLogDTO(resultSet.getString(1), resultSet.getString(2),
								resultSet.getString(3), resultSet.getString(4), resultSet.getString(5),
								Date.valueOf(resultSet.getString(6).substring(0, 10)), resultSet.getString(7), resultSet.getString(8).substring(0, 10)));
					}
					else {
						complaintLogDTO.add(new ComplaintLogDTO(resultSet.getString(1), resultSet.getString(2),
								resultSet.getString(3), resultSet.getString(4), resultSet.getString(5),
								Date.valueOf(resultSet.getString(6).substring(0, 10)), resultSet.getString(7), "NA"));
					}
					
				}

			}
			
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return complaintLogDTO;
	}
	@Override
	public Integer[] getComplaintCount() {
		Integer complaintCount[] = new Integer[3];
		try {
			try (PreparedStatement preparedStatement = connection
					.prepareStatement("select count(*) from complaint");
					PreparedStatement preparedStatement1 = connection
							.prepareStatement("select count(*) from complaint where complaint_status='PENDING'");
					PreparedStatement preparedStatement2 = connection
							.prepareStatement("select count(*) from complaint where complaint_status='COMPLETED'");
					) {
				ResultSet resultSet = preparedStatement.executeQuery();
				if(resultSet.next()) {
					complaintCount[0]=resultSet.getInt(1);
				}
				
				ResultSet resultSet1 = preparedStatement1.executeQuery();
				if(resultSet1.next()) {
					complaintCount[1]=resultSet1.getInt(1);
				}
				
				ResultSet resultSet2 = preparedStatement2.executeQuery();
					if(resultSet2.next()) {
					complaintCount[2]=resultSet2.getInt(1);
				}
					
				
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
	

		return complaintCount;
	}
}
