package com.cybage.dao;
import java.util.List;

import com.cybage.dto.ComplaintListDTO;
import com.cybage.model.*;

public interface IHodDAO {
	
	List<ComplaintListDTO> getComplaintByDepartmentId(int departmentId);
	
}
