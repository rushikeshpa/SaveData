package com.cybage.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cybage.model.Department;
import com.cybage.model.Role;
import com.cybage.model.User;
import com.cybage.utility.ConnectionUtility;

public class DepartmentDaoImpl implements IDepartmentDao {
	private static final Logger LOGGER = Logger.getLogger(AdminDaoImpl.class.getName());
	Connection connection = ConnectionUtility.getConnection();
	private IUserDao userDao;

	public DepartmentDaoImpl() {
		userDao = new UserDaoImpl();
	}

	@Override
	public boolean addDepartment(Department department) {
		try {

			try (PreparedStatement preparedStatement = connection
					.prepareStatement("insert into department values(default,?,?,?)");
					PreparedStatement preparedStatement1 = connection
							.prepareStatement("update  user set department_name = ? where user_id = ?");) {
				preparedStatement.setString(1, department.getDepartmentName());
				preparedStatement.setInt(2, department.getUser().getUserId());
				preparedStatement.setDate(3, Date.valueOf(LocalDate.now()));
				
				preparedStatement1.setString(1, department.getDepartmentName());
				preparedStatement1.setInt(2, department.getUser().getUserId());
				preparedStatement.executeUpdate();
				preparedStatement1.executeUpdate();
				return true;

			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public boolean removeDepartmentById(int departmentId) {
		Department department = getDepartmentById(departmentId);
		try (PreparedStatement preparedStatement = connection
				.prepareStatement("delete from department where department_id = ?");
				PreparedStatement preparedStatement1 = connection
						.prepareStatement("update  user set department_name = null where user_id = ?");) {
			preparedStatement.setInt(1, departmentId);
			preparedStatement1.setInt(1, department.getUser().getUserId());
			preparedStatement.executeUpdate();
			preparedStatement1.executeUpdate();
			
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public Department getDepartmentByHodId(int headOfHeadId) {
		Department department = null;
		try (PreparedStatement preparedStatement = connection
				.prepareStatement("select * from department where hod_id = ?");) {
			preparedStatement.setInt(1, headOfHeadId);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {

				department = new Department(resultSet.getInt(1), resultSet.getString(2),
						userDao.getUserById(resultSet.getInt(3)),
						Date.valueOf(resultSet.getString(4).substring(0, 10)));

			}

		} catch (SQLException e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return department;
	}

	@Override
	public Department getDepartmentById(int departmentId) {
		Department department = null;
		
		try (PreparedStatement preparedStatement = connection
				.prepareStatement("select * from department where department_id = ?");) {
			preparedStatement.setInt(1, departmentId);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {

				department = new Department(resultSet.getInt(1), resultSet.getString(2),
						userDao.getUserById(resultSet.getInt(3)),
						Date.valueOf(resultSet.getString(4).substring(0, 10)));

			}

		} catch (SQLException e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return department;
	}

	@Override
	public boolean editDepartment(Department department) {
		
		try (PreparedStatement preparedStatement = connection
				.prepareStatement("update department set department_name = ?, hod_id = ?  where department_id = ?;");PreparedStatement preparedStatement1 = connection
				.prepareStatement("update  user set department_name = ? where user_id = ?");) {
			
			preparedStatement.setString(1, department.getDepartmentName());
			preparedStatement.setInt(2, department.getUser().getUserId());
			preparedStatement.setInt(3, department.getDepartmentId());
			preparedStatement1.setString(1, department.getDepartmentName());
			preparedStatement1.setInt(2, department.getUser().getUserId());
			preparedStatement.executeUpdate();
			preparedStatement1.executeUpdate();
			return true;
		} catch (SQLException e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public List<Department> getAllDepartment() {
		
		List<Department> departmentList = new ArrayList<>();
		try {
			try (PreparedStatement preparedStatement = connection.prepareStatement("select * from department");
					ResultSet resultSet = preparedStatement.executeQuery();) {
				
				while (resultSet.next()) {
					departmentList.add(new Department(resultSet.getInt(1), resultSet.getString(2),
							userDao.getUserById(resultSet.getInt(3)),
							Date.valueOf(resultSet.getString(4).substring(0, 10))));
					
				}
				

			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			
			e.printStackTrace();
		}
		return departmentList;

	}

}
