package com.cybage.test;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Date;
import java.time.LocalDate;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.cybage.dao.DepartmentDaoImpl;
import com.cybage.dao.IDepartmentDao;
import com.cybage.dao.IUserDao;
import com.cybage.dao.UserDaoImpl;
import com.cybage.model.Department;
import com.cybage.model.Role;
import com.cybage.model.User;

class DepartmentDaoTest {
	private IDepartmentDao departmentDao;
//	boolean addDepartment(Department department);
//	boolean removeDepartmentById(int departmentId);
//	Department getDepartmentByHodId(int headOfHeadId);
//	Department getDepartmentById(int departmentId);

	public DepartmentDaoTest() {
	departmentDao = new DepartmentDaoImpl();
	}
	
	@BeforeAll
	public static void addDepartment() {
		IDepartmentDao departmentDao = new DepartmentDaoImpl();
		IUserDao userDao = new UserDaoImpl();
		Department department = new Department(userDao.getUserById(8), "Death", Date.valueOf(LocalDate.now()));
		assertEquals(false, departmentDao.addDepartment(department));
	}
	
//	@AfterAll
//	public static void removeDepartmentById() {
//		IDepartmentDao departmentDao = new DepartmentDaoImpl();
//		assertEquals(false, departmentDao.removeDepartmentById(100));
//	}
	
	@Test
	public void getDepartmentByHodId() {
		assertEquals(5, departmentDao.getDepartmentByHodId(7).getDepartmentId());
	}
	@Test
	public void getDepartmentById() {
		assertEquals(5, departmentDao.getDepartmentById(5).getDepartmentId());
	}
}
