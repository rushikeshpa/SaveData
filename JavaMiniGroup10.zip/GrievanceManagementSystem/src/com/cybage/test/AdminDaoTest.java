package com.cybage.test;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Date;
import java.time.LocalDate;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.cybage.dao.AdminDaoImpl;
import com.cybage.dao.IAdminDao;
import com.cybage.dao.IUserDao;
import com.cybage.model.Role;
import com.cybage.model.User;

class AdminDaoTest {
	IAdminDao adminDao;
	public AdminDaoTest() {
		adminDao = new AdminDaoImpl();
		}

	
	@BeforeAll
	public static void addHod() {
		IAdminDao adminDao = new AdminDaoImpl();
		User user = new User("Shankar", "shankar123", "shankar@123", "8237513295", "Pune",
				Role.DEPARTMENT_HEAD, Date.valueOf(LocalDate.now()));
		assertEquals(false, adminDao.addHod(user));
	}
	@AfterAll
	public static void removeHodById() {
		IAdminDao adminDao = new AdminDaoImpl();
		assertEquals(false, adminDao.removeHodById(8));
	}
	
	@Test
	public void getHodByDepartmentId() {
		assertEquals(7, adminDao.getHodByDepartmentId(5).getUserId());
	}
	@Test
	public void getHodById() {
		assertEquals(7, adminDao.getHodById(7).getUserId());
	}

}
