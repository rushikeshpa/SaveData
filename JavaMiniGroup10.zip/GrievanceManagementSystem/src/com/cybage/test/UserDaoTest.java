package com.cybage.test;



import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import org.junit.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;


import static org.junit.Assert.assertEquals;

import com.cybage.dao.IUserDao;
import com.cybage.dao.UserDaoImpl;
import com.cybage.model.Role;
import com.cybage.model.User;
import junit.runner.Version;

public class UserDaoTest {
	IUserDao userDao;

	public UserDaoTest() {
		userDao = new UserDaoImpl();
	}
	
	@BeforeAll
	public void registerUser() {
		User user = new User("Abhishek", "abhishek123", "admin@123", "8237513295", "Pune",
				Role.CITIZEN, Date.valueOf(LocalDate.now()));
		assertEquals(true,userDao.registerUser(user));
		
	}
	
	
	@BeforeEach
	public void auntheticateUser() {
		assertEquals(17,userDao.auntheticateUser("admin123", "admin@123").getUserId());
		
	}
	
	@Test
	public void getUserById() {
		assertEquals("Pratik", userDao.getUserById(6).getUserName());
	}
	@Test
	public void getUserByName() {
		assertEquals("Abhishek", userDao.getUserByName("Abhishek").getUserName());
	}
	


	
	

}
