$(document).ready(function () {
    let status = false;
    $("#departmentname").on("change", function () {
        let department_name = $("#departmentname").val();
     
    	$.ajax({
   		url: "http://localhost:8080/GrievanceManagementSystem/admin?action=checkDepartment",
   		type: "GET",
    		data: {
    			"departmentname": department_name
    		},
    		success: function(response) {
    			if (response === "exists") {   
    				
    				status = true;
    				$("#departmentname_error").css("display", "block");
    		        $("#departmentname_error").html("Department Already Exists");
    		        $("#departmentname").val("");
    			}
    		
       
    		else {
    			
        status = false;
        $("#departmentname_error").css("display", "none");
      }
    		},
    		error: function(xhr) {
				alert("in error: " + xhr.responseText);
			}
    });
   
  });
    $("#hodname").on("change", function () {
        let hod_name = $("#hodname").val();
        if (hod_name.length < 5) {
          status = true;
          $("#hodname_error").css("display", "block");
          $("#hodname_error").html("Enter Valid Name");
          $("#hodname").val("");
        } else {
          status = false;
          $("#hodname_error").css("display", "none");
        }
      });
    
  
   
  
    $("#submitform").click(function() {
        
        let hodname = $("#hodname").val();
        let departmentname = $("#departmentname").val();
        
        
        if (
        
        		hodname === "" ||
        		departmentname ===""
            ) {
          status = true;
          $("#empty_error").css("display","block");
        	$("#empty_error").html("All fields are compulsory");
        } else {
          status = false;
          $("#empty_error").css("display", "none");
          if (!status) {
    			
    			document.registerdepartment.submit();      
            
          }
        }
      
      });
});