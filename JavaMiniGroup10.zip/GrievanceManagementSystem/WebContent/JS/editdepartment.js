$(document).ready(function () {
    let status = false;
    $("#hodname").on("change", function () {
        let hod_name = $("#hodname").val();
        if (hod_name.length < 5) {
          status = true;
          $("#hodname_error").css("display", "block");
          $("#hodname_error").html("Length should be greater than 5");
          $("#hodname").val("");
        } else {
          status = false;
          $("#hodname_error").css("display", "none");
        }
      });
    $("#departmentname").on("change", function () {
        let department_name = $("#departmentname").val();
        if (department_name.length < 1) {
          status = true;
          $("#departmentname_error").css("display", "block");
          $("#departmentname_error").html("Enter Department Name");
          $("#departmentname").val("");
        } else {
          status = false;
          $("#departmentname_error").css("display", "none");
        }
      });
  
    $("#submitform").click(function() {
        
        let hodname = $("#hodname").val();
        let departmentname = $("#departmentname").val();
        
        
        if (
        
        		hodname === "" ||
        		departmentname ===""
            ) {
          status = true;
          $("#empty_error").css("display","block");
        	$("#empty_error").html("All fields are compulsory");
        } else {
          status = false;
          $("#empty_error").css("display", "none");
          if (!status) {
    			
    			document.editdepartment.submit();      
            
          }
        }
      
      });
});