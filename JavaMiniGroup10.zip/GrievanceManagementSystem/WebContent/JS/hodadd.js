$(document).ready(function () {
    let status = false;
    $("#hodname").on("change", function () {
        let hod_name = $("#hodname").val();
        if (hod_name.length < 5) {
          status = true;
          $("#hodname_error").css("display", "block");
          $("#hodname_error").html("Enter Valid Name");
          $("#hodname").val("");
        } else {
          status = false;
          $("#hodname_error").css("display", "none");
        }
      });

    $("#loginidhod").on("change", function () {
        let hod_loginId = $("#loginidhod").val();
       
    	$.ajax({
   		url: "http://localhost:8080/GrievanceManagementSystem/admin?action=checkUser",
   		type: "GET",
    		data: {
    			"username": hod_loginId
    		},
    		success: function(response) {
    			if (response === "exists") {   
    				
    				status = true;
    				$("#hodloginid_error").css("display", "block");
    		        $("#hodloginid_error").html("User Login Id Already Exists");
    		        $("#loginidhod").val("");
    			}
    		
       
    		else {
    			
        status = false;
        $("#hodloginid_error").css("display", "none");
      }
    		},
    		error: function(xhr) {
				alert("in error: " + xhr.responseText);
			}
    });
   
  });
         
     
    $("#passwordhod").on("change", function () {
        let hod_password = $("#passwordhod").val();
        if(!hod_password.match(/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/))
        {
            status = true;
            $("#hodpassword_error").css("display","block");
            $("#hodpassword_error").html("Password between 6 to 16 characters which which is alphanumeric and contains a special character");
           $("#passwordhod").val("");
  
        }
            else {
            $("#hodpassword_error").css("display", "none");
          }
        });
    $("#mobilehod").on("change", function () {
        let mobile = $("#mobilehod").val();
        if (mobile.length !== 10) {
          status = true;
          $("#hodmobile_error").css("display", "block");
          $("#hodmobile_error").html("Length should be 10");
          $("#mobilehod").val("");
        } else {
          status = false;
          $("#hodmobile_error").css("display", "none");
        }
      });
    $("#submitform").click(function() {
        
        let hodname = $("#hodname").val();
        let hodloginid = $("#loginidhod").val();
        let password = $("#passwordhod").val();
        let mobile = $("#mobilehod").val();
        
        
        if (
        
        		hodname === "" ||
        		hodloginid === "" ||
        		password === "" ||
        		mobile === "" 
            ) {
          status = true;
          $("#empty_error").css("display","block");
        	$("#empty_error").html("All fields are compulsory");
        } else {
          status = false;
          $("#empty_error").css("display", "none");
          if (!status) {
    			
    			document.registerhod.submit();      
            
          }
        }
      
      });
});