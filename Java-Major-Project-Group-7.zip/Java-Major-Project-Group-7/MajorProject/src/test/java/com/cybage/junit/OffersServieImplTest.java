package com.cybage.junit;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.cybage.service.OffersServieImpl;

public class OffersServieImplTest {
	OffersServieImpl offersService;

	
	@Before
	public void init() {
		offersService = new OffersServieImpl();
	}
	@Test
	public void testGetAllOffers() {
		assertNotEquals("abc", offersService.getAllOffers());
	}

	@Test
	public void testAddOffer() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateOffer() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteOfferById() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetOfferByName() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetOfferById() {
		fail("Not yet implemented");
	}

}
