package com.cybage.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class MembershipServieImplTest {

	@Test
	public void testGetAllMemberships() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetMembershipById() {
		fail("Not yet implemented");
	}

}
