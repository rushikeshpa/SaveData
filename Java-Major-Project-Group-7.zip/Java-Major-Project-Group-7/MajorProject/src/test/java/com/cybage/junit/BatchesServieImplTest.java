package com.cybage.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class BatchesServieImplTest {

	@Test
	public void testGetAllBatches() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddBatch() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateBatch() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteBatchesById() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetBatchByName() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetBatchesById() {
		fail("Not yet implemented");
	}

}
