package com.cybage.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class LogsServiceImplTest {

	@Test
	public void testGetAllLogs() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddLog() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetLogsById() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetLogsByName() {
		fail("Not yet implemented");
	}

}
