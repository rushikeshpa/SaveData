package com.cybage.service;

import java.util.List;

import com.cybage.pojo.Events;

public interface IEventsService {

	
	//get all events
	List<Events> getAllEvents();
}
