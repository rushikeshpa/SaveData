package com.cybage.exception;

public class OfferNotFoundException extends RuntimeException {
	public OfferNotFoundException(String message) {
		super(message);
	}
}
