package com.cybage.exception;

public class SportsNotFoundException extends RuntimeException {
	public SportsNotFoundException(String message) {
		super(message);
	}
}
