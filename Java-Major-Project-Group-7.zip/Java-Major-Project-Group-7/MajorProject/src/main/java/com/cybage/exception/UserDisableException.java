package com.cybage.exception;

public class UserDisableException extends  RuntimeException{

	public UserDisableException()
	{
		super();
	}
	
	public UserDisableException(String msg) {super();}
}
