import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.service';
import { HttpClient, HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.scss']
})
export class ChangepasswordComponent implements OnInit {
  
changepassword:any={
oldPassword:'',
newPassword:''
}


  constructor(private _login:LoginService) { }

  ngOnInit() {
    
  }


  formSubmit()
  {
    console.log(this.changepassword.oldPassword);
    console.log(this.changepassword.newPassword);
    
    this._login.changepassword(this.changepassword).subscribe((data:any)=>{
     console.log(data);
    },(error)=>{
      console.log(error);
    });
//this._login.changepassword(params);
  }

  // let params = new  HttpParams().set( 'oldpassword',changepassword.oldPassword,'newpassword',changePassword. newPassword);  
  

}
