import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { AdminService } from 'src/app/service/admin.service';
import { JsonpClientBackend } from '@angular/common/http';
import { Router } from '@angular/router';
@Component({
  selector: 'app-sportlist',
  templateUrl: './sportlist.component.html',
  styleUrls: ['./sportlist.component.scss']
})
export class SportlistComponent implements OnInit {

   displayedColumns: string[] = ['name', 'action','Disable','view'];
     dataSource: any;
      
    constructor(private adminService:AdminService) { }
    sport : any[] =[]
    // sports:any={
    //   sportId:0,
    //   sportName:''
    // }
   

  // ngOnInit(): void {
  //   this.adminService.getAllLockUser().subscribe(res=>{
  //     console.log(res);
  //     this.dataSource = new MatTableDataSource<any>(res);
    
  //   });
  ngOnInit(): void {
    this.adminService.getAllSports().subscribe(res=>{
      console.log(res);
      this.dataSource = new MatTableDataSource<any>(res);

    })
  }
  
 // redirect(pagename: string){
  //  this.router.navigate(['/'+sport]);
 // }

  // }
  // unlockUser(userId:number){
  //   this.adminService.unlockUser(userId).subscribe(res=>{
      
  //     console.log("in Unlock");
  //   })
    //  window.location.reload();
  // }
   
  
  

  

   applyFilter(event: Event) {
     const filterValue = (event.target as HTMLInputElement).value;
     this.dataSource.filter = filterValue.trim().toLowerCase();
   }
}
