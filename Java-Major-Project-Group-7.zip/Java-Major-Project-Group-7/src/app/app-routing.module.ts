import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SignupComponent } from './pages/signup/signup.component';
 
import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/login/login.component';
 
import { UserDashboardComponent } from './pages/users/user-dashboard/user-dashboard.component';
import { ManagerDashboardComponent } from './pages/manager/manager-dashboard/manager-dashboard.component';
import { AdminGuard } from './services/admin.guard';
import { NormalGuard } from './services/normal.guard';
import { MangagerGuard } from './services/mangager.guard';
import { SidenavComponent } from './pages/admin/sidenav/sidenav.component';
import { ProfileComponent } from './components/profile/profile.component';
import { AdminhomeComponent } from './pages/admin/adminhome/adminhome.component';
import { ViewSportsComponent } from './pages/admin/view-sports/view-sports.component';
import { AddSportsComponent } from './pages/admin/add-sports/add-sports.component';
import { ListofAcccountComponent } from './pages/admin/listof-acccount/listof-acccount.component';
import { ChangepasswordComponent } from './components/changepassword/changepassword.component';

const routes: Routes = [
  {
    path:'signup',
    component:SignupComponent,
    pathMatch:'full',
  },
  {
    path:'login',
    component:LoginComponent,
    pathMatch:'full',
  },
  {
    path:'',
    component:HomeComponent,
    pathMatch:'full',
  },
  {
    path:'admin',
    component:SidenavComponent,
    canActivate:[AdminGuard],
     children:[
      {
        path:'',
        component: AdminhomeComponent,
      },
      {
        path:'profile',
        component: ProfileComponent,
      },
      {
        path:'sports',
        component: ViewSportsComponent,
      },
      {
        path:'add-sports',
        component: AddSportsComponent,
      },
      {
        path:'list-of-account',
        component: ListofAcccountComponent,
      },
      {
        path:'change-password',
        component: ChangepasswordComponent,
      },
    ]

  },
  {
    path:'manager-dashboard',
    component:ManagerDashboardComponent,
    pathMatch:'full',
    canActivate:[MangagerGuard],
  }, 
  {
    path:'user-dashboard',
    component:UserDashboardComponent,
    pathMatch:'full',
    canActivate:[NormalGuard],
  },
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
