import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatToolbarModule} from '@angular/material/toolbar';
// side nav imports
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
 //forms imports
import {MatInputModule} from'@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import {MatCardModule} from '@angular/material/card';
 
 
import { NavbarComponent } from './components/navbar/navbar.component';
import { FooterComponent } from './components/footer/footer.component';
import { SignupComponent } from './pages/signup/signup.component'
 
import {HttpClientModule} from '@angular/common/http';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { HomeComponent } from './pages/home/home.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import {MatIconModule} from '@angular/material/icon';
import { LoginComponent } from './pages/login/login.component';
import { authInterceptorProviders } from './services/auth.interceptor';
import { DashboardComponent } from './pages/admin/dashboard/dashboard.component';
import { UserDashboardComponent } from './pages/users/user-dashboard/user-dashboard.component';
import { ManagerDashboardComponent } from './pages/manager/manager-dashboard/manager-dashboard.component';
import { SidenavComponent } from './pages/admin/sidenav/sidenav.component';
import { ProfileComponent } from './components/profile/profile.component';
import { ViewSportsComponent } from './pages/admin/view-sports/view-sports.component';
import { AddSportsComponent } from './pages/admin/add-sports/add-sports.component';
import { ListofAcccountComponent } from './pages/admin/listof-acccount/listof-acccount.component';
import { ChangepasswordComponent } from './components/changepassword/changepassword.component';
 
 

@NgModule({
  declarations: [
    AppComponent,
 
    NavbarComponent,
    FooterComponent,
    SignupComponent,
    HomeComponent,LoginComponent, DashboardComponent, UserDashboardComponent, ManagerDashboardComponent, SidenavComponent,ProfileComponent, ViewSportsComponent, AddSportsComponent, ListofAcccountComponent, ChangepasswordComponent  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,MatCardModule,FormsModule,ReactiveFormsModule,
 
    MatFormFieldModule,MatInputModule,MatButtonModule,
    HttpClientModule,MatSnackBarModule,MatToolbarModule,MatIconModule,
    MatSidenavModule,MatListModule
  ],
  providers: [authInterceptorProviders],
  bootstrap: [AppComponent]
})
export class AppModule { }
