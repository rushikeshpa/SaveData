import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ManagerService } from 'src/app/service/manager.service';


@Component({
  selector: 'app-sportlist',
  templateUrl: './sportlist.component.html',
  styleUrls: ['./sportlist.component.scss']
})
export class SportlistComponent implements OnInit {

  displayedColumns: string[] = ['name', 'action','Disable','view'];
  dataSource: any;
   
 constructor(private managerService:ManagerService) { }
 sport : any[] =[]

  

  ngOnInit(): void {
    this.managerService.getAllSports().subscribe(res=>{
      console.log(res);
      this.dataSource = new MatTableDataSource<any>(res);

    })
  }

}
