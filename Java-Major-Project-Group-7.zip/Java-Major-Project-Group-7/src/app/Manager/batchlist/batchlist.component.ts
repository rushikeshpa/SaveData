import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ManagerService } from 'src/app/service/manager.service';

@Component({
  selector: 'app-batchlist',
  templateUrl: './batchlist.component.html',
  styleUrls: ['./batchlist.component.scss']
})
export class BatchlistComponent implements OnInit {

  displayedColumns: string[] = ['position','name','fees','start','end','size','update','action'];
  dataSource: any;

  constructor(private managerService:ManagerService) { }
  batch : any[] =[]


  ngOnInit(): void {
   this.managerService.getAllBatches().subscribe(res=>{
     console.log(res);
     this.batch=res;
     this.dataSource = new MatTableDataSource<any>(res);

   })
 }
//   @ViewChild(MatPaginator)
// paginator!: MatPaginator;
//'name','fees','size','update','action','start','end'
// ngAfterViewInit() {
//   this.dataSource.paginator = this.paginator;
// }



}
