import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ManagerService } from 'src/app/service/manager.service';

@Component({
  selector: 'app-membershiplist',
  templateUrl: './membershiplist.component.html',
  styleUrls: ['./membershiplist.component.scss']
})
export class MembershiplistComponent implements OnInit {

  displayedColumns: string[] = ['position','name','date','approve','reject'];
  dataSource: any;

  constructor(private managerService:ManagerService) { }
  membership : any[] =[]


  ngOnInit(): void {
   this.managerService.getAllMemberships().subscribe(res=>{
     console.log(res);
     this.membership=res;
     this.dataSource = new MatTableDataSource<any>(res);

   })
 }

}
