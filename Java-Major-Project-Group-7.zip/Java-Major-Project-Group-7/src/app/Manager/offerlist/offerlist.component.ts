import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ManagerService } from 'src/app/service/manager.service';

@Component({
  selector: 'app-offerlist',
  templateUrl: './offerlist.component.html',
  styleUrls: ['./offerlist.component.scss']
})
export class OfferlistComponent implements OnInit {

  displayedColumns: string[] = ['position','name','Discount','Duration','status','update','action'];
  dataSource: any;

  constructor(private managerService:ManagerService) { }
  offer : any[] =[]


  ngOnInit(): void {
   this.managerService.getAllOffers().subscribe(res=>{
     console.log(res);
     this.offer=res;
     this.dataSource = new MatTableDataSource<any>(res);

   })

}

}
