import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private baseURL ='http://localhost:8080/';
  constructor(private httpClient: HttpClient) { }





  getAllOffers():Observable<any>{

    console.log(this.baseURL+"offers/getAllOffers");
  return this.httpClient.get<any>(this.baseURL+"offers/getAllOffers");}

  userId=1;

  getMembershipById():Observable<any>{

    console.log(this.baseURL+"membership/getMembershipById");
  return this.httpClient.get<any>(this.baseURL+"membership/getMembershipById/"+ this.userId);}

  getSportById():Observable<any>{

    console.log(this.baseURL+"sports/getSportById");
  return this.httpClient.get<any>(this.baseURL+"sports/getSportById/"+ this.userId);}
}
