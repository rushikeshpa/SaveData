import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private baseURL ='http://localhost:8080/';
  constructor(private httpClient: HttpClient) { }



  getAllSports():Observable<any>{

  
    return this.httpClient.get<any>(this.baseURL+"sports/getAllSports");
  
  }
  getAllBatches():Observable<any>{

      console.log(this.baseURL+"batches/getAllBatches");
    return this.httpClient.get<any>(this.baseURL+"batches/getAllBatches");

   //return this.httpClient.get<any>(this.baseURL+"sports/getAllSports");
  
  }
  getAllOffers():Observable<any>{

    console.log(this.baseURL+"offers/getAllOffers");
  return this.httpClient.get<any>(this.baseURL+"offers/getAllOffers");}
}
