import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listof-acccount',
  templateUrl: './listof-acccount.component.html',
  styleUrls: ['./listof-acccount.component.scss']
})
export class ListofAcccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
