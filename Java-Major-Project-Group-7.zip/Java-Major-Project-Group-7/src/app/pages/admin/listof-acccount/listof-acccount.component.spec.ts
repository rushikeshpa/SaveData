import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListofAcccountComponent } from './listof-acccount.component';

describe('ListofAcccountComponent', () => {
  let component: ListofAcccountComponent;
  let fixture: ComponentFixture<ListofAcccountComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListofAcccountComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListofAcccountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
