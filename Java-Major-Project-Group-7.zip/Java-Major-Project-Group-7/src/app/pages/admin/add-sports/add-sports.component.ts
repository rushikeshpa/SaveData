import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { SportsService } from 'src/app/services/sports/sports.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-sports',
  templateUrl: './add-sports.component.html',
  styleUrls: ['./add-sports.component.scss']
})
export class AddSportsComponent implements OnInit {
sports={
  name:'',
  description:'',
}
  constructor(private _snack:MatSnackBar,private _sport:SportsService ) { }

  ngOnInit(): void {
  }

  formSubmit()
  {
    if(this.sports.name.trim()==''||this.sports.description==null)
    {
      this._snack.open("Title Required!!!!",'',{
        duration:3000,
      });
    }

    //all done
    this._sport.addSports(this.sports).subscribe(
      (data:any)=>{
        Swal.fire('Sucess!!','Sports added successfully','success');
      },
      (error)=>{
        console.log(error);
        Swal.fire('Error!!','Server errorr!','error');
      }
    )
  }
}
