import { Component, OnInit } from '@angular/core';
import { SportsService } from 'src/app/services/sports/sports.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view-sports',
  templateUrl: './view-sports.component.html',
  styleUrls: ['./view-sports.component.scss']
})
export class ViewSportsComponent implements OnInit {

  sports=[
    {
      sportId:23 ,
      sportName:'Football' ,
      description:'Football is life',
      isActive:'Enable' ,
    },
    {
      sportId:23 ,
      sportName:'Football' ,
      description:'Football is life',
      isActive:'Enable' ,
    },
    {
      sportId:23 ,
      sportName:'Football' ,
      description:'Football is life',
      isActive:'Enable' ,
    },
    {
      sportId:23 ,
      sportName:'Football' ,
      description:'Football is life',
      isActive:'Enable' ,
    },
  ]
  constructor(private _sports:SportsService) { }

  ngOnInit(): void {
  
  this._sports.Sports().subscribe((data:any)=>{
    this.sports=data;
    console.log(this.sports);
  },(error)=>
  {
      console.log(error);
      Swal.fire("Error!!","error in laoding data",'error');
  }
  
  );
  }

}
