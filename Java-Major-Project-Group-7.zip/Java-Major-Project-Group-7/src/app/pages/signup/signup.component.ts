import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
 
 
import { UserService } from 'src/app/services/user.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import Swal from 'sweetalert2'
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  genders=['male','female'];
  SignupForm: FormGroup;
  public user={
    name:'',
    email:'',
    password:'',
    gender:''
  };
  constructor(private userService:UserService,private snack:MatSnackBar) { }

  ngOnInit() {
    this.SignupForm=new FormGroup(
      {
         'username':new FormControl(null,Validators.required),
         'email':new FormControl(null,[Validators.required,Validators.email]),
         'password':new FormControl(null,Validators.required),
         'gender':new FormControl('Male')
      });
  }

  formSubmit()
  { 

    if(this.user.name=='' || this.user.name==null)
    {
     // alert('User is required');
     this.snack.open('User name is required!!!!','',{
       duration:3000,
       verticalPosition:'top',
       horizontalPosition:'right'
     });
    return;
    }



    //add user : userService
    this.userService.addUser(this.user).subscribe(
      (data:any)=>{
       console.log(data);
        Swal.fire('Success Done!!','User Id '+data.id,'success');
      },(error)=>{
        console.log(error);
      this.snack.open('something went wrong!!','',{
        duration:3000,
      })
      }
    )
  }
}
