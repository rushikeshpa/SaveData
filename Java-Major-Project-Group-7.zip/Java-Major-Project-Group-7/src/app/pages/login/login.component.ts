import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { LoginService } from 'src/app/services/login.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
public loginData={
  username:'',
  password:'',

};

count:number=0;



LoginForm: FormGroup;
  constructor(private snack:MatSnackBar,private login:LoginService,private router : Router ) { }

  ngOnInit() {
    this.LoginForm=new FormGroup(
      {
         'username':new FormControl(null,Validators.required),
           'password':new FormControl(null,Validators.required),
         
      });
  }

  incrementCount()
  {
    this.count++;
    console.log(this.count);
  }
  formSubmit()
  {
    console.log('login button clicked');
    //checking null values
    if(this.loginData.username.trim()==''|| this.loginData.username=='null')
    {
      this.snack.open('Username is required!!','',{
        duration:3000,
      });
      return;
    }

    if(this.loginData.password.trim()==''|| this.loginData.password=='null')
    {
      this.snack.open('Password is required!!','',{
        duration:3000,
      });
      return;
    }



    this.login.generateToken(this.loginData).subscribe(
      (data:any)=>{
        console.log("success");
        console.log(data);

        //login..
        this.login.loginUser(data.token);

        this.login.getCurrentUser().subscribe(
          (user:any)=>{
            this.login.setUser(user);
            console.log(user);

            //redirect...ADMIN:admin-dashboard
            //redirect...NORMAL:normal-dashboard

            if(this.login.getUserRole()=='ADMIN')
            {
                //admin dashboard
                console.log('Inside Admin user role');   
                //window.location.href='/admin';
                this.router.navigate(['admin']);
                this.login.loginStatusSubject.next(true);
              }
              else if (this.login.getUserRole()=='MANAGER')
            {
              console.log('Inside  Manager user role');               
               //window.location.href='/manager-dashboard';
              this.router.navigate(['manager-dashboard']);
              this.login.loginStatusSubject.next(true);
            }
            else if(this.login.getUserRole()=='Normal')
            {  
                  console.log('Inside Normal user role');
                  //window.location.href='/user-dashboard';
                  this.router.navigate(['user-dashboard']);
                  this.login.loginStatusSubject.next(true);
            }
            else{
              this.login.logout();

            }



         
        }
            );

      },
      (error)=>{
        console.log('Error!');
        
        console.log(error);
        if(this.count==3)
        {
          Swal.fire('Locked Account','Sorry Account is locked!!','info');
        }
        else{
          this.snack.open("Invalid Details!! Try Again",'',{
            duration:3000,
          })
        }
        
      }
    )
     
  }

}
