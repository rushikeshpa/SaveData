import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OfferListUserComponent } from './offer-list-user.component';

describe('OfferListUserComponent', () => {
  let component: OfferListUserComponent;
  let fixture: ComponentFixture<OfferListUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OfferListUserComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OfferListUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
