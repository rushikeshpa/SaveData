import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-offer-list-user',
  templateUrl: './offer-list-user.component.html',
  styleUrls: ['./offer-list-user.component.scss']
})
export class OfferListUserComponent implements OnInit {


  
  dataSource: any;

  

  constructor(private userService:UserService) { }
  offer : any[] =[{}]


  ngOnInit(): void {
   this.userService.getAllOffers().subscribe(res=>{
     console.log(res);
     this.offer=res;
     this.dataSource = new MatTableDataSource<any>(res);

   })
  }
}
