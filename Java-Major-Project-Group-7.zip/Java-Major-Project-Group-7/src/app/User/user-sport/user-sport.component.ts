import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-user-sport',
  templateUrl: './user-sport.component.html',
  styleUrls: ['./user-sport.component.scss']
})
export class UserSportComponent implements OnInit {

  displayedColumns: string[] = ['name', 'action','Disable','view'];
  dataSource: any;
   
 constructor(private userService:UserService) { }
 sport : any[] =[]

  

  ngOnInit(): void {
    this.userService.getSportById().subscribe(res=>{
      console.log(res);
      this.dataSource = new MatTableDataSource<any>(res);

    })
  }

}
