import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-membership-details',
  templateUrl: './membership-details.component.html',
  styleUrls: ['./membership-details.component.scss']
})
export class MembershipDetailsComponent implements OnInit {

//   displayedColumns: string[] = ['position','name','offer','amount','duration','status'];
//   dataSource: any;

//   constructor(private userService:UserService) { }
//   membership : any[] =[]


//   ngOnInit(): void {
//    this.userService.getMembershipById().subscribe(res=>{
//      console.log(res);
//      this.membership=res;
//      this.dataSource = new MatTableDataSource<any>(res);

//    })
//  }
ngOnInit():void{}

}
