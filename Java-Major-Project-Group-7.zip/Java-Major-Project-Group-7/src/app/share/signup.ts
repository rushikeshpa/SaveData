 

export interface ILogin
{
    username:string;
    
    password:string;
   
    
}

