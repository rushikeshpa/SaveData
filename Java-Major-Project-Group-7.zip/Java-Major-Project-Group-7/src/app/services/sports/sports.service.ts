import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import baseUrl from '../helper';

@Injectable({
  providedIn: 'root'
})
export class SportsService {

  constructor(private _http:HttpClient) { }

  //load all the sports
  public Sports()
  {
    return this._http.get(`${baseUrl}/sports/getAllSports`);
  }

  //add new sports
  public addSports(sports:any)
  {
return this._http.post(`${baseUrl}/sports/sportsadd`,sports);
  }

}
